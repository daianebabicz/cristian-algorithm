import socket
import datetime
from dateutil import parser
from timeit import default_timer as timer
 
def sincronizarTempos():
    s = socket.socket()         
       
    porta = 8000    
       
    s.connect(('127.0.0.1', porta))
 
    tempoRequest = timer()
    tempoServidor = parser.parse(s.recv(1024).decode())
    tempoResposta = timer()
    tempoReal = datetime.datetime.now()
 
    print("Tempo do servidor: " + str(tempoServidor))
 
    latencia = tempoResposta - tempoRequest
 
    print("Latência do processo: " \
          + str(latencia) \
          + " segundo(s)")
 
    print("Tempo de clock no lado do cliente: " \
          + str(tempoReal))
 
    # synchronize process client clock time
    tempoCliente = tempoServidor \
                      + datetime.timedelta(seconds = \
                               (latencia) / 2)
 
    print("Processo sincronizado de tempo do cliente: " \
                                        + str(tempoCliente))
 
    # calculate synchronization error
    erro = tempoReal - tempoCliente
    print("Erro de Sync : "
                 + str(erro.total_seconds()) + " segundo(s)")
 
    s.close()       
 
if __name__ == '__main__':
      sincronizarTempos()