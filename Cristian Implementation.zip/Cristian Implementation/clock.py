import socket
import datetime
   
def iniciandoClock():
 
    s = socket.socket()
    print("Socket Criado!")

    porta = 8000
 
    s.bind(('', porta))
      
    s.listen(5)     
    print("Aguardando conexão...")
       
    while True:
       conexao, address = s.accept()     
       print('Servidor conectado ao endereco: ', address)
       print('Tempo: ', str(datetime.datetime.now()).encode())
       conexao.send(str(
                    datetime.datetime.now()).encode())
       
       conexao.close()
 
 
if __name__ == '__main__':
    iniciandoClock()